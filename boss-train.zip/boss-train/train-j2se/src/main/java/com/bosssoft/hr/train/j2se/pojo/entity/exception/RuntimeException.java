package com.bosssoft.hr.train.j2se.pojo.entity.exception;

/**
 * @version 1.0
 * @class: RuntimeException
 * @Description:
 * @Author: Dazo
 * @date: 26/4/2023下午9:13
 */
public class RuntimeException {

    public RuntimeException(String message, Throwable cause) {
    }
}
